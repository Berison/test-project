const gulp = require('gulp');
const { watch } = require('browser-sync');
const { src } = require('gulp');

// Connect plugins
const sass = require('gulp-sass')(require('sass')), // SCSS
    cssnano = require('gulp-cssnano'), // CSS min
    autoprefixer = require('gulp-autoprefixer'), // CSS vendor prefixes
    concat = require('gulp-concat'), // Concat
    uglify = require('gulp-uglify'), // JS min
    babel = require('gulp-babel'), // Babel JS
    rename = require('gulp-rename'), // Rename files
    imagemin = require('gulp-imagemin'), // Image min
    gcmq = require('gulp-group-css-media-queries'), // Media quaries
    csslint = require('gulp-csslint'), // CSS lint
    htmlhint = require("gulp-htmlhint"), // HTML validation
    browserSync = require('browser-sync').create(); // Local server

// Register tasks
gulp.task('browser-sync', function() {
    browserSync.init({
        server: {
            baseDir: "./dist"
        }
    });
    gulp.watch("src/*.html", gulp.series("html"));
    gulp.watch("src/js/*.js", gulp.series("scripts"));
    gulp.watch("src/scss/*.scss", gulp.series("scss"));
});

gulp.task('html', () => {
    return gulp.src("src/*.html")
        .pipe(htmlhint())
        .pipe(gulp.dest("dist"))
        .pipe(browserSync.stream())
})

gulp.task('scss', () => {
    return gulp.src("src/scss/*.scss")
        .pipe(concat('style.scss'))
        .pipe(sass())
        .pipe(autoprefixer({
            overrideBrowserslist: ['last 2 versions'],
            cascade: false
         }))
        .pipe(gcmq())
        .pipe(csslint())
        .pipe(gulp.dest("dist/css"))
        .pipe(cssnano())
        .pipe(rename({ suffix: '.min' }))
        .pipe(gulp.dest("dist/css"))
        .pipe(browserSync.stream());
})

gulp.task('scripts', () => {
    return gulp.src("src/js/*.js")
        .pipe(concat('scripts.js'))
        .pipe(babel({
			presets: ['@babel/preset-env']
		}))
        .pipe(gulp.dest("dist/js"))
        .pipe(uglify())
        .pipe(rename({ suffix: '.min' }))
        .pipe(gulp.dest("dist/js"))
        .pipe(browserSync.stream());
});

gulp.task('imagemin', () => {
    return gulp.src("src/image/*")
        .pipe(imagemin())
        .pipe(gulp.dest('dist/img'));
})

gulp.task('fonts', () => {
    return gulp.src("src/fonts/*")
        .pipe(gulp.dest('dist/fonts'));
})

gulp.task('swiper-js', () => {
    const modules = [
        'node_modules/swiper/swiper-bundle.min.js',
        'node_modules/swiper/swiper-bundle.min.js.map'
    ];

    return gulp.src(modules)
        .pipe(gulp.dest('dist/js'))
})

gulp.task('swiper-css', () => {
    const modules = [
        'node_modules/swiper/swiper-bundle.min.css'
    ];

    return gulp.src(modules)
        .pipe(gulp.dest('dist/css'))
})

// Default task
gulp.task('default', gulp.series('swiper-js', 'swiper-css', 'html', 'imagemin', 'fonts', 'scss', 'scripts', 'browser-sync'));