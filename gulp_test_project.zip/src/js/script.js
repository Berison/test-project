// Swiper 
const swiperOffer = new Swiper('.swiper-offer', {
  slidesPerView: 1,
  loop: true,
  navigation: {
    nextEl: ".swiper-offer .swiper-button-next",
    prevEl: ".swiper-offer .swiper-button-prev",
  },
  pagination: {
    el: ".offer .swiper-pagination",
    clickable: true
  }
});

// Burger
const burgerBtn = document.querySelector('.header .burger'),
  menuMob = document.querySelector('.header-inner__list');

const addActive = (...items) => {
  items.forEach(elem => elem.classList.add('active'));
}

const removeActive = (...items) => {
  items.forEach(elem => elem.classList.remove('active'));
}

burgerBtn.addEventListener('click', () =>
  menuMob.classList.contains('active') ?
    removeActive(burgerBtn, menuMob, document.body, document.documentElement) :
    addActive(burgerBtn, menuMob, document.body, document.documentElement)
)

// Anchor links menu
const allLinksHeader = document.querySelectorAll('.header-inner__list button, .footer-inner__list button');

allLinksHeader.forEach(elem => {
  elem.addEventListener('click', () => {
    removeActive(burgerBtn, menuMob, document.body, document.documentElement)
    document.querySelector(elem.dataset.href)
      .scrollIntoView({ behavior: 'smooth' });
  })
})

// Fixed menu
const menu = document.querySelector('.header');

const changeMenu = () =>
  (window.scrollY == 0) ?
    menu.classList.remove('scroll') :
    menu.classList.add('scroll');

changeMenu();

window.addEventListener('scroll', changeMenu)

// Validate form
const errorsIcon = '<svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.5 11C2.464 11 0 8.536 0 5.5C0 2.464 2.464 0 5.5 0C8.536 0 11 2.464 11 5.5C11 8.536 8.536 11 5.5 11ZM5.5 2.75C5.1975 2.75 4.95 2.9975 4.95 3.3V5.5C4.95 5.8025 5.1975 6.05 5.5 6.05C5.8025 6.05 6.05 5.8025 6.05 5.5V3.3C6.05 2.9975 5.8025 2.75 5.5 2.75ZM4.95 8.25V7.15H6.05V8.25H4.95Z" fill="#F61067"/></svg>';

const validateName = () => {
  const elem = document.querySelector('.name-label input'),
    parent = elem.parentElement;

  if (elem.value.length < 3) {
    parent.classList.add('error');
    parent.classList.remove('success');
    parent.querySelector('.error').innerHTML = `${errorsIcon} <p>Введіть мінімум 3 символи</p>`;
    return false;
  } else {
    parent.classList.remove('error');
    parent.classList.add('success');
    parent.querySelector('.error').innerHTML = '';
    return true;
  }

}

const validateEmail = () => {
  const elem = document.querySelector('.email-label input'),
    reg = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
    parent = elem.parentElement;

  if (elem.value.match(reg)) {
    parent.classList.remove('error');
    parent.classList.add('success');
    parent.querySelector('.error').innerHTML = ''
    return true;
  } else {
    parent.classList.add('error');
    parent.classList.remove('success');
    parent.querySelector('.error').innerHTML = `${errorsIcon} <p>Не вірний формат почти</p>`;
    return false;
  }
}

// Mask phone
const maskPhone = event => {
  let keyCode;
  event.keyCode && (keyCode = event.keyCode);
  let pos = event.target.selectionStart;
  if (pos < 3) event.preventDefault();
  let matrix = "+38 (___) ___-__-__",
    i = 0,
    def = matrix.replace(/\D/g, ""),
    val = event.target.value.replace(/\D/g, ""),
    newValue = matrix.replace(/[_\d]/g, function (a) {
      return i < val.length ? val.charAt(i++) || def.charAt(i) : a;
    });
  i = newValue.indexOf("_");
  if (i != -1) {
    i < 5 && (i = 3);
    newValue = newValue.slice(0, i);
  }
  let reg = matrix.substr(0, event.target.value.length).replace(/_+/g,
    function (a) {
      return "\\d{1," + a.length + "}";
    }).replace(/[+()]/g, "\\$&");
  reg = new RegExp("^" + reg + "$");
  if (!reg.test(event.target.value) || event.target.value.length < 5 || keyCode > 47 && keyCode < 58) event.target.value = newValue;
  if (event.type == "blur" && event.target.value.length < 5) event.target.value = "";
}

document.querySelectorAll('.phone-label input').forEach(elem => elem.addEventListener("input", maskPhone, false))
document.querySelectorAll('.phone-label input').forEach(elem => elem.addEventListener("focus", maskPhone, false))
document.querySelectorAll('.phone-label input').forEach(elem => elem.addEventListener("blur", maskPhone, false))
document.querySelectorAll('.phone-label input').forEach(elem => elem.addEventListener("keydown", maskPhone, false))

// Submit form
const formInner = document.querySelectorAll('.help-inner__form > form'),
  popupThank = document.querySelector('.success-popup'),
  closePopupThank = document.querySelector('.success-popup .close'),
  overlay = document.querySelector('.overlay');

formInner.forEach(elem => elem.addEventListener('submit', e => {
  const allInpts = e.target.querySelectorAll('.label-inner input');

  allInpts.forEach(el => {
    if (el.value.length > 64) {
      el.parentElement.querySelector('.error').innerHTML = 'Завелика кількість знаків';
    } else {
      el.parentElement.querySelector('.error').innerHTML = '';
    }
  })

  if (validateName() && validateEmail()) {
    addActive(popupThank, overlay, document.body, document.documentElement);
    closePopupThank.addEventListener('click', () => removeActive(popupThank, overlay, document.body, document.documentElement))
    // For analitics
    // setTimeout(()=>{
    //   document.location.href = '?thank';
    // }, 2000)
  }
}))

const script = document.createElement('script');
script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBAst16pChZK7yjmJFhFj1BbvM0REeJNMw&callback=initMap';

window.initMap = function () {
  const myLatLng = { lat: 49.8327787, lng: 23.9421962 };
  const map = new google.maps.Map(document.getElementById("map"), {
    center: myLatLng,
    zoom: 16,
  });
  new google.maps.Marker({
    position: myLatLng,
    map,
  });
};

document.head.appendChild(script);

// Map logic info
const listItemsMap = document.querySelectorAll('.contacts-inner__item'),
  listItemTitle = document.querySelectorAll('.contacts-inner__item .info'),
  handleListItemTitle = document.querySelector('.map-info strong');

listItemsMap.forEach((elem, index) => {
  elem.addEventListener('click', () => {
    removeActive(...listItemsMap);
    addActive(elem);
    handleListItemTitle.innerHTML = listItemTitle[index].innerHTML;
    if(window.outerWidth <= 1024) {
      document.getElementById("map")
        .scrollIntoView({ behavior: 'smooth' });
    }
  })
})

// Dynamic date
const dateFooterSpan = document.querySelector('.copyright .date');

dateFooterSpan.innerHTML = new Date().getFullYear();